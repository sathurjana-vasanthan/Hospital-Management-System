import tempfile
import unittest
from datetime import date, timedelta
from repositories.json_store import JsonRepository
from services.hospital import HospitalService

class HospitalTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.s=HospitalService(JsonRepository(self.tmp.name))
        self.p=self.s.register_patient('Test Patient','0771234567','22','Female','Jaffna')
        self.d=self.s.register_doctor('Dr Test','0779876543','General','2000','Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday','09:00,10:00')
        self.day=(date.today()+timedelta(days=1)).isoformat()
    def tearDown(self):self.tmp.cleanup()
    def test_registration_persists(self):
        self.assertEqual(self.s.get('patients',self.p)['name'],'Test Patient')
    def test_double_booking(self):
        self.s.book(self.p,self.d,self.day,'09:00','Consultation')
        with self.assertRaises(ValueError):self.s.book(self.p,self.d,self.day,'09:00','Another')
    def test_bill(self):
        a=self.s.book(self.p,self.d,self.day,'09:00','Consultation')
        self.s.record_treatment(a,'Fever','Paracetamol','Rest','1500')
        b=self.s.create_bill(a,'1000','500')
        self.assertEqual(self.s.get('bills',b)['total'],'5000.00')
        self.s.mark_paid(b)
        self.assertEqual(self.s.summary()['Paid Revenue (LKR)'],'5000.00')

if __name__=='__main__':unittest.main()
