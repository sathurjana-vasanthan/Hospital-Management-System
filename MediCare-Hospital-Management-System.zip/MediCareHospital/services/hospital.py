from datetime import datetime, date
from decimal import Decimal, InvalidOperation
from dataclasses import asdict
from models.entities import Patient, Doctor, Appointment, Treatment, Bill

PREFIX = {'patients':'P','doctors':'D','appointments':'A','treatments':'T','bills':'B'}

class HospitalService:
    """Business rules are independent of the GUI and JSON implementation."""
    def __init__(self, repository):
        self.repo = repository

    def all(self, kind):
        return self.repo.all(kind)

    def get(self, kind, record_id):
        return next((r for r in self.all(kind) if r['id'] == record_id), None)

    def _next_id(self, kind):
        numbers = [int(r['id'][1:]) for r in self.all(kind) if r['id'][1:].isdigit()]
        return f'{PREFIX[kind]}{max(numbers, default=0)+1:03d}'

    def _add(self, kind, obj):
        rows = self.all(kind)
        rows.append(asdict(obj))
        self.repo.save(kind, rows)
        return obj.id

    def _required(self, **fields):
        for key, value in fields.items():
            if not str(value).strip():
                raise ValueError(f'{key.replace("_", " ").title()} is required')

    def money(self, value):
        try:
            amount = Decimal(str(value)).quantize(Decimal('0.01'))
        except (InvalidOperation, ValueError):
            raise ValueError('Enter a valid amount')
        if amount < 0 or not amount.is_finite():
            raise ValueError('Amount must be zero or more')
        return amount

    def register_patient(self, name, phone, age, gender, address):
        self._required(name=name, phone=phone, age=age, gender=gender)
        if not str(age).isdigit() or int(age)>120:
            raise ValueError('Age must be between 0 and 120')
        if not phone.replace('+','').replace(' ','').isdigit():
            raise ValueError('Phone number must contain digits')
        return self._add('patients', Patient(self._next_id('patients'), name.strip(), phone.strip(), int(age), gender, address))

    def register_doctor(self, name, phone, specialization, fee, available_days, available_times):
        self._required(name=name, phone=phone, specialization=specialization, available_days=available_days, available_times=available_times)
        if not phone.replace('+','').replace(' ','').isdigit():
            raise ValueError('Phone number must contain digits')
        return self._add('doctors', Doctor(self._next_id('doctors'), name.strip(), phone.strip(), specialization.strip(), str(self.money(fee)), available_days.strip(), available_times.strip()))

    def book(self, patient_id, doctor_id, date_str, time, reason):
        self._required(patient_id=patient_id, doctor_id=doctor_id, date=date_str, time=time)
        if not self.get('patients', patient_id) or not self.get('doctors', doctor_id):
            raise ValueError('Choose a registered patient and doctor')
        try:
            selected = datetime.strptime(date_str, '%Y-%m-%d').date()
            datetime.strptime(time, '%H:%M')
        except ValueError:
            raise ValueError('Use date YYYY-MM-DD and time HH:MM (24-hour)')
        if selected < date.today():
            raise ValueError('Cannot book appointments in the past')
        doctor = self.get('doctors', doctor_id)
        day = selected.strftime('%A').lower()
        allowed_days = [d.strip().lower() for d in doctor['available_days'].split(',')]
        allowed_times = [t.strip() for t in doctor['available_times'].split(',')]
        if day not in allowed_days or time not in allowed_times:
            raise ValueError('Doctor is unavailable at that day/time. Check listed availability.')
        if any(a['doctor_id']==doctor_id and a['date']==date_str and a['time']==time and a['status']=='Scheduled' for a in self.all('appointments')):
            raise ValueError('Doctor is already booked at that time')
        return self._add('appointments', Appointment(self._next_id('appointments'),patient_id,doctor_id,date_str,time,reason))

    def change_appointment(self, appointment_id, status):
        if status not in ('Completed','Cancelled'):
            raise ValueError('Invalid status')
        rows = self.all('appointments')
        for row in rows:
            if row['id']==appointment_id:
                if row['status']!='Scheduled':
                    raise ValueError('Only scheduled appointments can be changed')
                row['status']=status
                self.repo.save('appointments',rows)
                return
        raise ValueError('Appointment not found')

    def record_treatment(self, appointment_id, diagnosis, medicine, description, cost):
        self._required(appointment_id=appointment_id, diagnosis=diagnosis)
        if not self.get('appointments',appointment_id):
            raise ValueError('Appointment not found')
        if any(t['appointment_id']==appointment_id for t in self.all('treatments')):
            raise ValueError('A treatment already exists for this appointment')
        return self._add('treatments',Treatment(self._next_id('treatments'),appointment_id,diagnosis,medicine,description,str(self.money(cost))))

    def create_bill(self, appointment_id, lab, pharmacy):
        appointment = self.get('appointments',appointment_id)
        if not appointment:
            raise ValueError('Appointment not found')
        if any(b['appointment_id']==appointment_id for b in self.all('bills')):
            raise ValueError('A bill already exists for this appointment')
        doctor = self.get('doctors',appointment['doctor_id'])
        treatment = next((t for t in self.all('treatments') if t['appointment_id']==appointment_id),None)
        consultation = self.money(doctor['fee'])
        treatment_cost = self.money(treatment['cost'] if treatment else 0)
        lab_cost, pharmacy_cost = self.money(lab), self.money(pharmacy)
        total = consultation+treatment_cost+lab_cost+pharmacy_cost
        return self._add('bills',Bill(self._next_id('bills'),appointment_id,str(consultation),str(treatment_cost),str(lab_cost),str(pharmacy_cost),str(total)))

    def mark_paid(self, bill_id):
        rows=self.all('bills')
        for row in rows:
            if row['id']==bill_id:
                row['status']='Paid'
                self.repo.save('bills',rows)
                return
        raise ValueError('Bill not found')

    def summary(self):
        appts=self.all('appointments')
        bills=self.all('bills')
        return {
            'Patients':len(self.all('patients')),
            'Doctors':len(self.all('doctors')),
            'Today Appointments':sum(a['date']==date.today().isoformat() for a in appts),
            'Scheduled':sum(a['status']=='Scheduled' for a in appts),
            'Completed':sum(a['status']=='Completed' for a in appts),
            'Paid Revenue (LKR)':str(sum((Decimal(b['total']) for b in bills if b['status']=='Paid'),Decimal('0.00'))),
            'Unpaid Bills':sum(b['status']!='Paid' for b in bills)
        }
