from dataclasses import dataclass, asdict
from decimal import Decimal

@dataclass
class Person:
    id: str
    name: str
    phone: str

@dataclass
class Patient(Person):
    age: int
    gender: str
    address: str

@dataclass
class Doctor(Person):
    specialization: str
    fee: str
    available_days: str
    available_times: str

@dataclass
class Appointment:
    id: str
    patient_id: str
    doctor_id: str
    date: str
    time: str
    reason: str
    status: str = 'Scheduled'

@dataclass
class Treatment:
    id: str
    appointment_id: str
    diagnosis: str
    medicine: str
    description: str
    cost: str

@dataclass
class Bill:
    id: str
    appointment_id: str
    consultation: str
    treatment: str
    lab: str
    pharmacy: str
    total: str
    status: str = 'Unpaid'
