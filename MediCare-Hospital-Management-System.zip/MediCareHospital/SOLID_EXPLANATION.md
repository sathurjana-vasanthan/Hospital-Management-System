# APDP OOP and SOLID Notes

- **Encapsulation:** `HospitalService` groups validation and business operations behind methods; GUI does not write JSON directly.
- **Inheritance:** `Patient` and `Doctor` extend `Person` dataclass.
- **Abstraction:** `Repository` defines the persistence contract with abstract methods.
- **Polymorphism:** `HospitalService` can work with any implementation of `Repository` that satisfies the contract.
- **S — Single Responsibility:** GUI renders controls, service enforces business rules, repository persists data, models represent entities.
- **O — Open/Closed:** A new repository (for example, an in-memory repository for testing) can replace `JsonRepository` without changing service methods.
- **L — Liskov Substitution:** A conforming subclass of `Repository` can be substituted for `JsonRepository` without breaking `HospitalService`.
- **I — Interface Segregation:** Repository exposes only `all` and `save`, the operations currently required by service logic. Larger applications could split read and write interfaces.
- **D — Dependency Inversion:** `HospitalService` receives a repository via its constructor and never imports `JsonRepository`.

For a stronger APDP submission, extend this prototype with dedicated service classes, report exporter abstractions, UML diagrams, and tests for each principle.
