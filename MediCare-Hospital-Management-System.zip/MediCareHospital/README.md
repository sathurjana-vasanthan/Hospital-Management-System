# Medi Care Hospital Management System

A standalone Python Tkinter GUI for an APDP classroom demonstration. Uses local JSON files and fictional patient data.

## Run on Windows

1. Install Python 3.10 or newer (check **Add Python to PATH** during installation).
2. Open this folder in VS Code or a terminal.
3. Run `python main.py` (or `py main.py` on Windows).

No third-party Python packages are required. Tkinter is normally included in Windows Python installations.

## Run tests

`python -m unittest discover -s tests -v`

## Demo workflow

1. Register a patient.
2. Register a doctor. Enter days as `Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday` and times as `09:00,10:00`.
3. Book an appointment using patient ID, doctor ID, YYYY-MM-DD date, and one of the doctor's available HH:MM slots.
4. Record a treatment for the appointment ID.
5. Generate a bill for that appointment; lab and pharmacy charges are entered separately.
6. Mark the bill paid and check the dashboard and Reports page.

## Design

- `models/`: dataclass domain entities (Person, Patient, Doctor, Appointment, Treatment, Bill).
- `repositories/`: repository abstraction and JSON persistence with atomic file replacement.
- `services/`: business rules, validation, conflict checks, billing and reports.
- `gui/`: Tkinter presentation layer.
- `tests/`: unittest tests with temporary storage.

## Limitations

This is an **educational prototype**, not production clinical software. Use only fictional data. JSON is not appropriate for real patient information, concurrent hospital staff access, or regulated medical records. This version includes create, search, appointment status changes, bill payment, and CSV reports. It does not implement record editing, rescheduling, authentication, access control, audit logs, partial payments, or PDF bill export.


## Enhanced dashboard and downloadable reports
The dashboard now has icon-based quick-access tiles for all six modules while retaining the navy/blue theme.
The Reports screen provides **PDF** and **CSV** downloads for Patients, Doctors, Appointments, Treatments, Billing and a Hospital Summary.
Install PDF support with `pip install -r requirements.txt` before running `python main.py`.
Use fictional demonstration records only; local JSON files are not suitable for real patient medical information.
