import csv
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from datetime import date

NAV = [('▦', 'Dashboard', None), ('♙', 'Patients', 'patients'), ('✚', 'Doctors', 'doctors'), ('▤', 'Appointments', 'appointments'), ('✧', 'Treatments', 'treatments'), ('▣', 'Billing', 'bills'), ('▥', 'Reports', 'reports')]
FIELDS = {
 'patients':[('name','Full Name'),('phone','Phone Number'),('age','Age'),('gender','Gender'),('address','Address')],
 'doctors':[('name','Doctor Name'),('phone','Phone Number'),('specialization','Specialization'),('fee','Consultation Fee (LKR)'),('available_days','Available Days (Monday,Tuesday)'),('available_times','Available Times (09:00,10:00)')],
 'appointments':[('patient_id','Patient ID'),('doctor_id','Doctor ID'),('date','Date (YYYY-MM-DD)'),('time','Time (HH:MM)'),('reason','Reason for Visit')],
 'treatments':[('appointment_id','Appointment ID'),('diagnosis','Diagnosis'),('medicine','Prescribed Medicine'),('description','Treatment Description'),('cost','Treatment Cost (LKR)')],
 'bills':[('appointment_id','Appointment ID'),('lab','Laboratory Cost (LKR)'),('pharmacy','Pharmacy Cost (LKR)')]
}
C = {'navy':'#12243C','navy2':'#1B3554','blue':'#377DDF','bg':'#F3F6FB','white':'#FFFFFF','text':'#1C304A','muted':'#78889C','line':'#E4EAF2','pale':'#EAF2FF','green':'#1EAD83','red':'#D85D6B'}

class HospitalApp(tk.Tk):
    def __init__(self, service):
        super().__init__()
        self.service = service
        self.title('MediCare  |  Hospital Management Workspace')
        self.geometry('1360x830')
        self.minsize(1010, 650)
        self.configure(bg=C['bg'])
        self._style()
        self.sidebar = tk.Frame(self, bg=C['navy'], width=242)
        self.sidebar.pack(side='left', fill='y')
        self.sidebar.pack_propagate(False)
        brand = tk.Frame(self.sidebar, bg=C['navy'])
        brand.pack(fill='x', padx=23, pady=(34, 34))
        tk.Label(brand, text='✚', font=('Segoe UI Symbol', 23, 'bold'), bg=C['blue'], fg='white', width=2, height=1).pack(side='left', padx=(0,12))
        tk.Label(brand, text='MediCare\nHOSPITAL', justify='left', font=('Segoe UI', 14, 'bold'), fg='white', bg=C['navy']).pack(side='left')
        tk.Label(self.sidebar, text='WORKSPACE', bg=C['navy'], fg='#7794B3', font=('Segoe UI', 9, 'bold')).pack(anchor='w', padx=27, pady=(0,13))
        self.nav_buttons = {}
        for icon, label, kind in NAV:
            button = tk.Button(self.sidebar, text=f'  {icon}    {label}', command=lambda k=kind:self.show(k), bg=C['navy'], fg='#C0D0E3', activebackground=C['navy2'], activeforeground='white', relief='flat', bd=0, anchor='w', padx=15, pady=13, cursor='hand2', font=('Segoe UI', 11))
            button.pack(fill='x', padx=13, pady=2)
            self.nav_buttons[kind] = button
        tk.Frame(self.sidebar, bg='#2B4260', height=1).pack(fill='x', padx=22, pady=(25, 15))
        tk.Label(self.sidebar, text='MEDI CARE  •  SRI LANKA', bg=C['navy'], fg='#829BB6', font=('Segoe UI', 9)).pack(anchor='w', padx=25)
        tk.Button(self.sidebar, text='  ↪    Exit application', command=self.destroy, bg=C['navy'], fg='#E8A9B2', relief='flat', bd=0, anchor='w', padx=17, pady=14, font=('Segoe UI', 11), cursor='hand2').pack(side='bottom', fill='x', padx=13, pady=22)
        shell = tk.Frame(self, bg=C['bg'])
        shell.pack(side='left', fill='both', expand=True)
        top = tk.Frame(shell, bg='white', height=69, highlightbackground=C['line'], highlightthickness=1)
        top.pack(fill='x')
        top.pack_propagate(False)
        tk.Label(top, text='HOSPITAL MANAGEMENT  /  WORKSPACE', bg='white', fg=C['muted'], font=('Segoe UI', 9, 'bold')).pack(side='left', padx=31)
        tk.Label(top, text='●  System online', bg='white', fg=C['green'], font=('Segoe UI', 10, 'bold')).pack(side='right', padx=32)
        self.content = tk.Frame(shell, bg=C['bg'])
        self.content.pack(fill='both', expand=True, padx=30, pady=25)
        self.show(None)

    def _style(self):
        s = ttk.Style(self)
        s.theme_use('clam')
        s.configure('Treeview', background='white', fieldbackground='white', foreground=C['text'], borderwidth=0, rowheight=38, font=('Segoe UI', 10))
        s.map('Treeview', background=[('selected', C['pale'])], foreground=[('selected', C['navy'])])
        s.configure('Treeview.Heading', background='#F0F4F9', foreground='#51637A', font=('Segoe UI', 10, 'bold'), relief='flat', padding=(9,12))
        s.map('Treeview.Heading', background=[('active','#E8F0FB')])
        s.configure('TEntry', padding=9, fieldbackground='white')
        s.configure('TCombobox', padding=8)
        s.configure('Accent.TButton', padding=(18,11), background=C['blue'], foreground='white', font=('Segoe UI', 10, 'bold'), borderwidth=0)
        s.map('Accent.TButton', background=[('active','#276AC7')])
        s.configure('Quiet.TButton', padding=(14,10), background='white', foreground=C['text'], font=('Segoe UI', 10), borderwidth=1)
        s.map('Quiet.TButton', background=[('active',C['pale'])])

    def clear(self):
        for child in self.content.winfo_children(): child.destroy()

    def header(self, title, subtitle='', action=None):
        row=tk.Frame(self.content,bg=C['bg'])
        row.pack(fill='x', pady=(0,19))
        left=tk.Frame(row,bg=C['bg']);left.pack(side='left')
        tk.Label(left,text=title,bg=C['bg'],fg=C['text'],font=('Segoe UI',25,'bold')).pack(anchor='w')
        tk.Label(left,text=subtitle,bg=C['bg'],fg=C['muted'],font=('Segoe UI',10)).pack(anchor='w',pady=(4,0))
        if action: ttk.Button(row,text=action[0],command=action[1],style='Accent.TButton').pack(side='right',pady=8)

    def show(self,kind):
        self.clear()
        for key,button in self.nav_buttons.items():
            active=key==kind
            button.configure(bg=C['navy2'] if active else C['navy'],fg='white' if active else '#C0D0E3')
        if kind is None:self.dashboard()
        elif kind=='reports':self.reports()
        else:self.module(kind)

    def _card(self,parent,title,value,accent,caption):
        box=tk.Frame(parent,bg='white',highlightbackground=C['line'],highlightthickness=1,padx=21,pady=17)
        tk.Frame(box,bg=accent,height=4).pack(fill='x',pady=(0,14))
        tk.Label(box,text=title.upper(),bg='white',fg=C['muted'],font=('Segoe UI',9,'bold')).pack(anchor='w')
        tk.Label(box,text=str(value),bg='white',fg=C['text'],font=('Segoe UI',25,'bold')).pack(anchor='w',pady=(6,2))
        tk.Label(box,text=caption,bg='white',fg=accent,font=('Segoe UI',9)).pack(anchor='w')
        return box

    def dashboard(self):
        self.header('Hospital Administration', 'Manage hospital operations from one central workspace.', ('＋  Register patient', lambda: self.show('patients')))
        metrics = self.service.summary()
        grid = tk.Frame(self.content, bg=C['bg'])
        grid.pack(fill='x', pady=(0, 12))
        highlights = [('Patients', '♙', C['blue']), ('Doctors', '✚', C['green']),
                      ('Today Appointments', '▦', '#8B68D6'), ('Paid Revenue (LKR)', '▣', '#D18A39')]
        for i, (key, symbol, color) in enumerate(highlights):
            card = tk.Frame(grid, bg='white', highlightbackground=C['line'], highlightthickness=1, padx=15, pady=12)
            card.grid(row=0, column=i, sticky='nsew', padx=5)
            tk.Label(card, text=symbol, bg=C['pale'], fg=color, font=('Segoe UI Symbol', 19, 'bold'), width=3).pack(side='left', padx=(0, 12))
            right = tk.Frame(card, bg='white'); right.pack(side='left', anchor='w')
            tk.Label(right, text=str(metrics.get(key, 0)), bg='white', fg=C['text'], font=('Segoe UI', 19, 'bold')).pack(anchor='w')
            tk.Label(right, text=key, bg='white', fg=C['muted'], font=('Segoe UI', 9)).pack(anchor='w')
            grid.columnconfigure(i, weight=1)

        self.section_title('Quick access', 'Select a module to open it')
        shortcuts = tk.Frame(self.content, bg=C['bg'])
        shortcuts.pack(fill='x', pady=(0, 16))
        tiles = [
            ('♙', 'Patient Registration', 'patients'), ('✚', 'Doctor Management', 'doctors'),
            ('▦', 'Appointments', 'appointments'), ('✧', 'Treatments', 'treatments'),
            ('▣', 'Billing & Payments', 'bills'), ('▥', 'Download Reports', 'reports'),
        ]
        for i, (symbol, title, kind) in enumerate(tiles):
            tile = tk.Frame(shortcuts, bg='white', highlightbackground=C['line'], highlightthickness=1)
            tile.grid(row=i//3, column=i%3, sticky='nsew', padx=5, pady=5)
            btn = tk.Button(tile, text=f'{symbol}\n{title}', command=lambda k=kind: self.show(k),
                            bg='white', fg=C['text'], activebackground=C['pale'], activeforeground=C['blue'],
                            font=('Segoe UI Symbol', 12, 'bold'), relief='flat', bd=0,
                            cursor='hand2', pady=14)
            btn.pack(fill='both', expand=True)
        for i in range(3): shortcuts.columnconfigure(i, weight=1)
        self.section_title('Recent appointments', 'Latest saved appointments')
        self.table('appointments', self.service.all('appointments')[-10:])

    def section_title(self,title,caption=''):
        bar=tk.Frame(self.content,bg=C['bg']);bar.pack(fill='x',pady=(5,7))
        tk.Label(bar,text=title,bg=C['bg'],fg=C['text'],font=('Segoe UI',15,'bold')).pack(side='left')
        if caption:tk.Label(bar,text=caption,bg=C['bg'],fg=C['muted'],font=('Segoe UI',9)).pack(side='right')

    def table(self,kind,rows):
        holder=tk.Frame(self.content,bg='white',highlightbackground=C['line'],highlightthickness=1,padx=10,pady=10)
        holder.pack(fill='both',expand=True,pady=(5,4))
        fallback={'patients':['id','name','phone','age','gender','address'],'doctors':['id','name','phone','specialization','fee','available_days','available_times'],'appointments':['id','patient_id','doctor_id','date','time','reason','status'],'treatments':['id','appointment_id','diagnosis','medicine','description','cost'],'bills':['id','appointment_id','consultation','treatment','lab','pharmacy','total','status']}
        cols=list(rows[0].keys()) if rows else fallback[kind]
        tree=ttk.Treeview(holder,columns=cols,show='headings',selectmode='browse')
        vs=ttk.Scrollbar(holder,orient='vertical',command=tree.yview)
        hs=ttk.Scrollbar(holder,orient='horizontal',command=tree.xview)
        tree.configure(yscrollcommand=vs.set,xscrollcommand=hs.set)
        tree.grid(row=0,column=0,sticky='nsew');vs.grid(row=0,column=1,sticky='ns');hs.grid(row=1,column=0,sticky='ew')
        holder.rowconfigure(0,weight=1);holder.columnconfigure(0,weight=1)
        for col in cols:
            tree.heading(col,text=col.replace('_',' ').title())
            tree.column(col,width=max(125,len(col)*13),minwidth=95,stretch=False,anchor='w')
        for idx,row in enumerate(rows):
            tree.insert('','end',values=[row.get(c,'') for c in cols],tags=('even' if idx%2==0 else 'odd',))
        tree.tag_configure('even',background='#FFFFFF')
        tree.tag_configure('odd',background='#F8FAFD')
        return tree

    def module(self,kind):
        singular={'patients':'Patient','doctors':'Doctor','appointments':'Appointment','treatments':'Treatment','bills':'Bill'}[kind]
        self.header(f'{singular} Management',f'Manage {kind}, create new records, and review history')
        frame=tk.Frame(self.content,bg='white',highlightbackground=C['line'],highlightthickness=1,padx=22,pady=15)
        frame.pack(fill='x',pady=(0,16))
        tk.Label(frame,text=f'＋  New {singular.lower()}',bg='white',fg=C['text'],font=('Segoe UI',14,'bold')).grid(row=0,column=0,columnspan=4,sticky='w',pady=(0,14))
        entries={}
        for idx,(key,label) in enumerate(FIELDS[kind]):
            r=1+idx//2*2;c=(idx%2)*2
            tk.Label(frame,text=label,bg='white',fg=C['muted'],font=('Segoe UI',9,'bold')).grid(row=r,column=c,columnspan=2,sticky='w',padx=(5,15),pady=(4,4))
            entry=ttk.Entry(frame,width=29)
            entry.grid(row=r+1,column=c,columnspan=2,sticky='ew',padx=(5,24),pady=(0,10))
            entries[key]=entry
        if kind=='appointments':entries['date'].insert(0,date.today().isoformat())
        if kind=='bills':
            for key in ('lab','pharmacy'):entries[key].insert(0,'0')
        if kind=='treatments':entries['cost'].insert(0,'0')
        frame.columnconfigure(0,weight=1);frame.columnconfigure(2,weight=1)
        def submit():
            args=[entries[k].get().strip() for k,_ in FIELDS[kind]]
            method={'patients':self.service.register_patient,'doctors':self.service.register_doctor,'appointments':self.service.book,'treatments':self.service.record_treatment,'bills':self.service.create_bill}[kind]
            try:
                record_id=method(*args)
                messagebox.showinfo('Record saved',f'Saved successfully: {record_id}')
                self.show(kind)
            except (ValueError,OSError) as exc:messagebox.showerror('Unable to save',str(exc))
        ttk.Button(frame,text=f'＋  Save {singular}',command=submit,style='Accent.TButton').grid(row=1+(len(FIELDS[kind])+1)//2*2,column=2,columnspan=2,sticky='e',pady=(6,1),padx=20)
        self.section_title(f'All {kind.title()}','Select a record for available actions')
        actions=tk.Frame(self.content,bg=C['bg']);actions.pack(fill='x',pady=(2,6))
        tk.Label(actions,text='⌕  Search records',bg=C['bg'],fg=C['muted'],font=('Segoe UI',10)).pack(side='left')
        search=ttk.Entry(actions,width=25);search.pack(side='left',padx=10)
        ttk.Button(actions,text='Search',command=lambda:self.filter_table(kind,search.get()),style='Quiet.TButton').pack(side='left',padx=3)
        ttk.Button(actions,text='Refresh',command=lambda:self.show(kind),style='Quiet.TButton').pack(side='left',padx=3)
        if kind=='appointments':
            ttk.Button(actions,text='✓ Complete',command=lambda:self.set_status('appointments','Completed'),style='Quiet.TButton').pack(side='right',padx=3)
            ttk.Button(actions,text='Cancel selected',command=lambda:self.set_status('appointments','Cancelled'),style='Quiet.TButton').pack(side='right',padx=3)
        if kind=='bills':ttk.Button(actions,text='✓ Mark paid',command=lambda:self.set_status('bills','Paid'),style='Quiet.TButton').pack(side='right',padx=3)
        self.active_kind=kind
        self.active_tree=self.table(kind,self.service.all(kind))

    def filter_table(self,kind,term):
        rows=[r for r in self.service.all(kind) if term.lower() in ' '.join(str(v) for v in r.values()).lower()]
        for child in self.active_tree.get_children():self.active_tree.delete(child)
        cols=self.active_tree['columns']
        for row in rows:self.active_tree.insert('','end',values=[row.get(c,'') for c in cols])

    def set_status(self,kind,status):
        selection=self.active_tree.selection()
        if not selection:
            messagebox.showwarning('Select a record','Please select a row first.');return
        record_id=self.active_tree.item(selection[0])['values'][0]
        try:
            if kind=='appointments':self.service.change_appointment(str(record_id),status)
            else:self.service.mark_paid(str(record_id))
            self.show(kind)
        except ValueError as exc:messagebox.showerror('Error',str(exc))

    def reports(self):
        self.header('Reports & Downloads', 'Generate and save hospital reports as PDF or CSV files')
        metrics = self.service.summary()
        grid = tk.Frame(self.content, bg=C['bg']); grid.pack(fill='x', pady=(0, 12))
        for i, (key, value) in enumerate(metrics.items()):
            self._card(grid, key, value, [C['blue'], C['green'], '#8B68D6'][i%3], 'From saved records').grid(row=i//4, column=i%4, sticky='nsew', padx=4, pady=4)
        for i in range(4): grid.columnconfigure(i, weight=1)
        self.section_title('Download reports', 'Choose a report and a file format')
        panel = tk.Frame(self.content, bg='white', highlightbackground=C['line'], highlightthickness=1, padx=16, pady=12)
        panel.pack(fill='x', pady=6)
        report_types = [('▤', 'Patients', 'patients'), ('✚', 'Doctors', 'doctors'),
                        ('▦', 'Appointments', 'appointments'), ('✧', 'Treatments', 'treatments'),
                        ('▣', 'Billing', 'bills'), ('▥', 'Hospital Summary', 'summary')]
        for i, (icon, title, kind) in enumerate(report_types):
            item = tk.Frame(panel, bg='#F8FAFD', highlightbackground=C['line'], highlightthickness=1, padx=12, pady=9)
            item.grid(row=i//2, column=i%2, sticky='ew', padx=6, pady=6)
            tk.Label(item, text=icon, bg='#F8FAFD', fg=C['blue'], font=('Segoe UI Symbol', 20)).pack(side='left', padx=(3, 12))
            tk.Label(item, text=title, bg='#F8FAFD', fg=C['text'], font=('Segoe UI', 11, 'bold')).pack(side='left')
            ttk.Button(item, text='↓ PDF', command=lambda k=kind: self.export_pdf(k), style='Accent.TButton').pack(side='right', padx=(7, 0))
            ttk.Button(item, text='↓ CSV', command=lambda k=kind: self.export(k), style='Quiet.TButton').pack(side='right')
        for i in range(2): panel.columnconfigure(i, weight=1)

    def _report_rows(self, kind):
        if kind == 'summary':
            return [{'Metric': key, 'Value': value} for key, value in self.service.summary().items()]
        return self.service.all(kind)

    def export(self, kind):
        rows = self._report_rows(kind)
        if not rows:
            messagebox.showinfo('No records', 'Nothing to export yet.'); return
        path = filedialog.asksaveasfilename(defaultextension='.csv', initialfile=f'{kind}_report.csv', filetypes=[('CSV files', '*.csv')])
        if not path: return
        try:
            columns = list(dict.fromkeys(key for row in rows for key in row))
            with open(path, 'w', newline='', encoding='utf-8-sig') as f:
                writer = csv.DictWriter(f, fieldnames=columns)
                writer.writeheader(); writer.writerows(rows)
            messagebox.showinfo('Download complete', f'CSV report saved to:\n{path}')
        except (OSError, ValueError) as exc:
            messagebox.showerror('Export failed', str(exc))

    def export_pdf(self, kind):
        rows = self._report_rows(kind)
        if not rows:
            messagebox.showinfo('No records', 'Nothing to export yet.'); return
        path = filedialog.asksaveasfilename(defaultextension='.pdf', initialfile=f'{kind}_report.pdf', filetypes=[('PDF files', '*.pdf')])
        if not path: return
        try:
            from reportlab.lib import colors
            from reportlab.lib.pagesizes import A4, landscape
            from reportlab.lib.styles import getSampleStyleSheet
            from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, LongTable, TableStyle
            from reportlab.lib.enums import TA_CENTER
            from reportlab.lib.styles import ParagraphStyle
            from xml.sax.saxutils import escape
            from datetime import datetime
            page = landscape(A4)
            doc = SimpleDocTemplate(path, pagesize=page, leftMargin=30, rightMargin=30, topMargin=34, bottomMargin=30)
            styles = getSampleStyleSheet()
            title_style = ParagraphStyle('HospitalTitle', parent=styles['Heading1'], textColor=colors.HexColor('#163A5F'), alignment=TA_CENTER, fontSize=17, spaceAfter=8)
            subtitle_style = ParagraphStyle('HospitalSub', parent=styles['Normal'], alignment=TA_CENTER, textColor=colors.HexColor('#64748B'), spaceAfter=16)
            story = [Paragraph('MEDI CARE HOSPITAL (PVT) LTD', title_style),
                     Paragraph(f'{kind.replace("_", " ").title()} Report  |  Generated: {datetime.now():%d %B %Y, %I:%M %p}', subtitle_style)]
            columns = list(dict.fromkeys(key for row in rows for key in row))
            # Limit very long free-text fields to keep wide reports legible on A4.
            cell_style = ParagraphStyle('Cell', parent=styles['Normal'], fontSize=7, leading=9)
            header_style = ParagraphStyle('HeadCell', parent=cell_style, textColor=colors.white)
            def cell(value, style):
                txt = str(value if value is not None else '')
                if len(txt) > 95: txt = txt[:92] + '...'
                return Paragraph(escape(txt), style)
            data = [[cell(col.replace('_', ' ').title(), header_style) for col in columns]]
            data.extend([[cell(row.get(col, ''), cell_style) for col in columns] for row in rows])
            available_width = page[0] - 60
            widths = [available_width / len(columns)] * len(columns)
            table = LongTable(data, colWidths=widths, repeatRows=1, hAlign='CENTER')
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#163A5F')),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F2F6FA')]),
                ('VALIGN', (0, 0), (-1, -1), 'TOP'),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 7),
                ('TOPPADDING', (0, 0), (-1, -1), 7),
                ('LEFTPADDING', (0, 0), (-1, -1), 5),
                ('RIGHTPADDING', (0, 0), (-1, -1), 5),
                ('LINEBELOW', (0, 0), (-1, 0), 0.7, colors.HexColor('#2980B9')),
            ]))
            story.extend([table, Spacer(1, 10), Paragraph(f'Total records: {len(rows)}', styles['Normal'])])
            doc.build(story)
            messagebox.showinfo('Download complete', f'PDF report saved to:\n{path}')
        except ImportError:
            messagebox.showerror('PDF support missing', 'Install ReportLab using: pip install reportlab')
        except (OSError, ValueError, Exception) as exc:
            messagebox.showerror('PDF export failed', str(exc))
