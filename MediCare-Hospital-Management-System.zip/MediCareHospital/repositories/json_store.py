import json
import os
import tempfile
from pathlib import Path
from .base import Repository

KINDS = ('patients', 'doctors', 'appointments', 'treatments', 'bills')

class JsonRepository(Repository):
    def __init__(self, folder=None):
        self.folder = Path(folder) if folder else Path(__file__).resolve().parents[1] / 'data'
        self.folder.mkdir(parents=True, exist_ok=True)
        for kind in KINDS:
            path = self.folder / f'{kind}.json'
            if not path.exists():
                self.save(kind, [])

    def _path(self, kind):
        if kind not in KINDS:
            raise ValueError('Unknown record type')
        return self.folder / f'{kind}.json'

    def all(self, kind):
        with self._path(kind).open('r', encoding='utf-8') as f:
            rows = json.load(f)
        if not isinstance(rows, list):
            raise ValueError(f'{kind}.json must contain a list')
        return rows

    def save(self, kind, rows):
        path = self._path(kind)
        fd, name = tempfile.mkstemp(dir=self.folder, prefix='.tmp_', suffix='.json')
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                json.dump(rows, f, indent=2, ensure_ascii=False)
                f.flush()
                os.fsync(f.fileno())
            os.replace(name, path)
        finally:
            if os.path.exists(name):
                os.remove(name)
