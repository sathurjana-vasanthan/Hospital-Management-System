from tkinter import messagebox
from repositories.json_store import JsonRepository
from services.hospital import HospitalService
from gui.app import HospitalApp

def main():
    try:
        repo=JsonRepository()
        app=HospitalApp(HospitalService(repo))
        app.mainloop()
    except Exception as exc:
        messagebox.showerror('Startup Error',str(exc))
        raise

if __name__=='__main__':
    main()
